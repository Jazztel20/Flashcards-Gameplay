console.log("Log from JS entrypoint");
