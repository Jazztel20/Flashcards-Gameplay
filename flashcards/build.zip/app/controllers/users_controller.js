import User from '#models/user';
import { errors } from '@adonisjs/session';
export default class UsersController {
    service;
    async show({ response }) {
        const users = await User.query().orderBy('created_at');
        console.log(users.length);
        return response.ok({
            message: 'Success',
            data: { users },
        });
    }
    async create(ctx) {
        const payload = ctx.request.body();
        try {
            const post = await this.service.create({
                userId: ctx.auth.user?.id,
                payload,
            });
            try {
                await this.service.storeAttachments(ctx, post.id);
            }
            catch (error) {
                await post.delete();
                ctx.session.flash('errors', {
                    images: 'Invalid file.',
                });
            }
        }
        catch (error) {
            if (error instanceof errors.E_SESSION_NOT_MUTABLE) {
                const reducedErrors = error.message;
                ctx.session.flash('errors', reducedErrors);
            }
        }
        return ctx.response.redirect().back();
    }
    async update({ params, request }) {
        const data = request.only(['pseudo', 'email', 'password']);
        const user = await User.findOrFail(params.id);
        user.merge(data);
        await user.save();
        return user;
    }
    async destroy(ctx) {
        const user = await User.findOrFail(ctx.params.id);
        await user.delete();
        return ctx.response.redirect().back();
    }
}
//# sourceMappingURL=users_controller.js.map