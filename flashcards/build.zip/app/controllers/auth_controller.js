import User from '#models/user';
import { registerValidator, loginValidator } from '#validators/auth';
export default class AuthController {
    async registerShow({ view }) {
        return view.render('pages/auth/register');
    }
    async register({ request, response, auth }) {
        const data = await request.validateUsing(registerValidator);
        const user = await User.create(data);
        await auth.use('web').login(user);
        return response.redirect().toRoute('home');
    }
    async loginShow({ view }) {
        return view.render('pages/auth/login');
    }
    async login({ request, response, auth }) {
        const { email, password } = await request.validateUsing(loginValidator);
        const user = await User.verifyCredentials(email, password);
        await auth.use('web').login(user);
        return response.redirect().toRoute('home');
    }
    async logout({ auth, session, response }) {
        await auth.use('web').logout();
        session.flash('success', "L'utilisateur s'est déconnecté avec succès");
        return response.redirect().toRoute('home');
    }
}
//# sourceMappingURL=auth_controller.js.map