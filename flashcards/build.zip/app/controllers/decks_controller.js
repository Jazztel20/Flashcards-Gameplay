import Deck from '#models/deck';
import { deckValidator } from '#validators/deck';
export default class DecksController {
    async showSingleDeck({ params, view }) {
        const deck = await Deck.query()
            .preload('flashcards', (flashcardQuery) => {
            flashcardQuery.orderBy('created_at', 'asc');
        })
            .where('id', params.id)
            .firstOrFail();
        return view.render('components/decks/detail', { deck });
    }
    async index({ view, auth }) {
        const user = auth.user;
        const query = Deck.query();
        if (user) {
            if (user.isAdmin) {
            }
            else {
                query.where((q) => {
                    q.where('is_public', true).orWhere('user_id', user.id);
                });
            }
        }
        else {
            query.where('is_public', true);
        }
        const decks = await query.orderBy('updated_at', 'desc');
        return view.render('home', { decks });
    }
    async create({ view }) {
        return view.render('decks/create');
    }
    async store({ request, response, auth, session }) {
        const data = await request.validateUsing(deckValidator);
        await Deck.create({
            name: data.name,
            userId: auth.user.id,
        });
        session.flash('success', 'Le deck a été ajouté avec succès !');
        return response.redirect().toRoute('home');
    }
    async edit({ params, view, auth, response, session }) {
        const deck = await Deck.findOrFail(params.id);
        if (auth.user?.id !== deck.userId && !auth.user?.isAdmin) {
            session.flash('error', "Vous n'avez pas la permission de modifier ce deck.");
            return response.redirect().toRoute('home');
        }
        return view.render('decks/edit', { deck });
    }
    async update({ params, request, response, session, auth }) {
        const deck = await Deck.findOrFail(params.id);
        if (auth.user?.id !== deck.userId && !auth.user?.isAdmin) {
            session.flash('error', "Vous n'avez pas la permission de modifier ce deck.");
            return response.redirect().toRoute('home');
        }
        const data = await request.validateUsing(deckValidator);
        deck.merge(data);
        await deck.save();
        session.flash('success', 'Le deck a été mis à jour avec succès !');
        return response.redirect().toRoute('home');
    }
    async destroy({ params, response, session, auth }) {
        const deck = await Deck.findOrFail(params.id);
        if (auth.user?.id !== deck.userId && !auth.user?.isAdmin) {
            session.flash('error', "Vous n'avez pas la permission de supprimer ce deck.");
            return response.redirect().toRoute('home');
        }
        await deck.delete();
        session.flash('success', 'Le deck a été supprimé avec succès !');
        return response.redirect().toRoute('home');
    }
    async publish({ params, response, session, auth }) {
        const deck = await Deck.query().where('id', params.id).preload('flashcards').firstOrFail();
        if (auth.user?.id !== deck.userId && !auth.user?.isAdmin) {
            session.flash('error', "Vous n'avez pas la permission de publier ce deck.");
            return response.redirect().toRoute('home');
        }
        if (deck.flashcards.length === 0) {
            session.flash('error', 'Impossible de publier un deck sans flashcards.');
            return response.redirect().back();
        }
        deck.isPublic = true;
        deck.publishedDate = DateTime.now();
        await deck.save();
        session.flash('success', 'Le deck a été publié avec succès !');
        return response.redirect().back();
    }
    async play({ params, view, auth, response, session }) {
        const deck = await Deck.query().where('id', params.id).preload('flashcards').firstOrFail();
        const canPlay = deck.isPublic || (auth.user && (auth.user.id === deck.userId || auth.user.isAdmin));
        if (!canPlay) {
            session.flash('error', "Vous n'avez pas accès à ce deck.");
            return response.redirect().toRoute('home');
        }
        if (deck.flashcards.length === 0) {
            session.flash('error', 'Ce deck ne contient aucune flashcard.');
            return response.redirect().back();
        }
        return view.render('decks/play', {
            deck,
            flashcardsJson: JSON.stringify(deck.flashcards),
        });
    }
}
import { DateTime } from 'luxon';
//# sourceMappingURL=decks_controller.js.map