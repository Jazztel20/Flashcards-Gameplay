import vine from '@vinejs/vine';
async function recordUniq(db, value, ctx, tableName, fieldName) {
    const record = await db
        .from(tableName)
        .whereNot('id', ctx.meta.userId)
        .where(fieldName, value)
        .first();
    return !record;
}
export const updateUserValidator = vine.compile(vine.object({
    pseudo: vine
        .string()
        .trim()
        .unique(async (...ctxParams) => await recordUniq(...ctxParams, 'user', 'pseudo'))
        .minLength(1)
        .maxLength(50),
    email: vine
        .string()
        .unique(async (...ctxParams) => await recordUniq(...ctxParams, 'user', 'email'))
        .email(),
}));
//# sourceMappingURL=user.js.map