import vine from '@vinejs/vine';
async function recordUniq(db, value, ctx, tableName, fieldName) {
    const record = await db
        .from(tableName)
        .whereNot('id', ctx.meta.flashcardId)
        .where(fieldName, value)
        .first();
    return !record;
}
export const flashcardValidator = vine.compile(vine.object({
    question: vine.string().trim().minLength(2),
    answer: vine.string().trim().minLength(2),
}));
export const updateFlashCardValidator = vine.compile(vine.object({
    question: vine
        .string()
        .trim()
        .unique(async (...ctxParams) => await recordUniq(...ctxParams, 'flashcard', 'question'))
        .minLength(1)
        .maxLength(50),
    answer: vine
        .string()
        .unique(async (...ctxParams) => await recordUniq(...ctxParams, 'flashcard', 'answer'))
        .minLength(1)
        .maxLength(50),
}));
//# sourceMappingURL=flashcard.js.map