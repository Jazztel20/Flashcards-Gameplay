import factory from '@adonisjs/lucid/factories';
import Deck from '#models/deck';
import User from '#models/user';
import { DateTime } from 'luxon';
export const DeckFactory = factory
    .define(Deck, async ({ faker }) => {
    const user = await User.query().orderByRaw('RAND()').first();
    return {
        name: faker.commerce.department() + ' Deck',
        isPublic: true,
        userId: user ? user.id : 1,
        publishedDate: DateTime.fromJSDate(faker.date.past()),
    };
})
    .build();
//# sourceMappingURL=deck_factory.js.map