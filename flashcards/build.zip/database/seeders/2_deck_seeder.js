import { BaseSeeder } from '@adonisjs/lucid/seeders';
import { DeckFactory } from '#database/factories/deck_factory';
export default class extends BaseSeeder {
    async run() {
        await DeckFactory.createMany(10);
    }
}
//# sourceMappingURL=2_deck_seeder.js.map